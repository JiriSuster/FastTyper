import pywebio.input as input
from pywebio import start_server
from pywebio.output import put_text
from geocoding_api import get_coordinates_current_location
from weather_api import get_weather


def app():
    # ziskane akualni souradnice uziivatele na zaklade IP adresy
    lat, lon = get_coordinates_current_location()
    # stahneme data o pocasi
    weather_data = get_weather(lat, lon)
    # zobrazime json
    put_text(weather_data['current'])


if __name__ == '__main__':
    start_server(app, debug=True)
